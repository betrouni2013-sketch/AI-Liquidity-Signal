package com.example.ailiquidity

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max

private val BG = Color(0xFF050D19)
private val PANEL = Color(0xFF101E32)
private val PANEL2 = Color(0xFF142943)
private val MUTED = Color(0xFF9FB4D0)
private val GREEN = Color(0xFF16D96B)
private val RED = Color(0xFFFF454F)
private val BLUE = Color(0xFF16A9FF)
private val GOLD = Color(0xFFFFC857)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { LiquidityDashboard() } }
    }
}

private data class Candle(val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double, val quoteVolume: Double)
private data class FrameData(
    val interval: String, val rsi: Double, val last: Double,
    val high: Double, val low: Double, val volume: Double, val bias: String,
    val closes: List<Double>, val candles: List<Candle>, val sweep: String,
    val structure: String, val referenceHigh: Double, val referenceLow: Double,
    val ema20: Double, val ema50: Double, val atr14: Double,
    val volumeRatio: Double, val technicalScore: Int
)
private data class MarketState(
    val symbol: String = "BTCUSDT", val price: Double? = null,
    val change24h: Double? = null, val frames: List<FrameData> = emptyList(),
    val loading: Boolean = true, val error: String? = null,
    val updatedAt: String = "—"
)

private fun getJson(path: String): String {
    val conn = URL("https://data-api.binance.vision$path").openConnection() as HttpURLConnection
    conn.requestMethod = "GET"; conn.connectTimeout = 10000; conn.readTimeout = 10000
    conn.setRequestProperty("Accept", "application/json")
    return try {
        if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
        conn.inputStream.bufferedReader().use { it.readText() }
    } finally { conn.disconnect() }
}

private fun loadSymbol(symbol: String, callback: (MarketState) -> Unit) {
    thread(name = "market-$symbol") {
        try {
            val ticker = JSONObject(getJson("/api/v3/ticker/24hr?symbol=$symbol"))
            val price = ticker.getString("lastPrice").toDouble()
            val change = ticker.getString("priceChangePercent").toDouble()
            val frames = listOf("1h", "15m", "5m").map { interval ->
                val arr = JSONArray(getJson("/api/v3/klines?symbol=$symbol&interval=$interval&limit=100"))
                val candles = (0 until arr.length()).map { i ->
                    val r = arr.getJSONArray(i)
                    Candle(r.getString(1).toDouble(), r.getString(2).toDouble(), r.getString(3).toDouble(),
                        r.getString(4).toDouble(), r.getString(5).toDouble(), r.getString(7).toDouble())
                }
                analyzeFrame(interval, candles.dropLast(1))
            }
            callback(MarketState(symbol, price, change, frames, false, null,
                SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())))
        } catch (e: Exception) {
            callback(MarketState(symbol = symbol, loading = false, error = e.message ?: "Network error"))
        }
    }
}

private fun rsi(candles: List<Candle>, period: Int = 14): Double {
    if (candles.size <= period) return 50.0
    var gain = 0.0; var loss = 0.0
    for (i in 1..period) { val d = candles[i].close - candles[i - 1].close; if (d >= 0) gain += d else loss -= d }
    var ag = gain / period; var al = loss / period
    for (i in period + 1 until candles.size) { val d = candles[i].close - candles[i - 1].close; ag = (ag * (period - 1) + max(d, 0.0)) / period; al = (al * (period - 1) + max(-d, 0.0)) / period }
    if (al == 0.0) return 100.0
    val rs = ag / al; return 100.0 - 100.0 / (1.0 + rs)
}
private fun ema(values: List<Double>, period: Int): Double {
    if (values.isEmpty()) return 0.0
    val alpha = 2.0 / (period + 1.0); var result = values.take(minOf(period, values.size)).average()
    for (v in values.drop(minOf(period, values.size))) result = alpha * v + (1.0 - alpha) * result
    return result
}
private fun atr(candles: List<Candle>, period: Int = 14): Double {
    if (candles.size < 2) return 0.0
    return candles.zipWithNext().map { (a, b) -> max(b.high - b.low, max(kotlin.math.abs(b.high - a.close), kotlin.math.abs(b.low - a.close))) }.takeLast(period).average()
}
private fun analyzeFrame(interval: String, candles: List<Candle>): FrameData {
    val value = rsi(candles); val closes = candles.map { it.close }
    val recentMean = closes.takeLast(10).average(); val priorMean = closes.dropLast(10).takeLast(20).average()
    val bias = when { recentMean > priorMean && value > 52 -> "Bullish"; recentMean < priorMean && value < 48 -> "Bearish"; else -> "Neutral" }
    val ema20 = ema(closes, 20); val ema50 = ema(closes, 50); val atr14 = atr(candles)
    val recentVol = candles.takeLast(20).map { it.quoteVolume }.average()
    val priorVol = candles.dropLast(20).takeLast(20).map { it.quoteVolume }.average().coerceAtLeast(0.0000001)
    val volumeRatio = recentVol / priorVol
    val reference = candles.dropLast(1).takeLast(20)
    val refHigh = reference.maxOf { it.high }; val refLow = reference.minOf { it.low }; val latest = candles.last()
    val sweep = when { latest.high > refHigh && latest.close < refHigh -> "Upper liquidity sweep"; latest.low < refLow && latest.close > refLow -> "Lower liquidity sweep"; else -> "No clear sweep" }
    val structure = when { latest.close > refHigh -> "Bullish structure break"; latest.close < refLow -> "Bearish structure break"; else -> "Inside previous range" }
    var score = 0
    if (ema20 > ema50) score += 20 else if (ema20 < ema50) score -= 20
    if (latest.close > ema20) score += 10 else if (latest.close < ema20) score -= 10
    when { value in 52.0..65.0 -> score += 15; value > 65.0 -> score += 5; value in 35.0..48.0 -> score -= 15; value < 35.0 -> score -= 5 }
    if (sweep.contains("Lower")) score += 20; if (sweep.contains("Upper")) score -= 20
    if (structure.contains("Bullish")) score += 20; if (structure.contains("Bearish")) score -= 20
    if (volumeRatio >= 1.5 && latest.close > latest.open) score += 10
    if (volumeRatio >= 1.5 && latest.close < latest.open) score -= 10
    score = score.coerceIn(-100, 100)
    return FrameData(interval, value, closes.last(), candles.takeLast(30).maxOf { it.high }, candles.takeLast(30).minOf { it.low },
        candles.takeLast(20).sumOf { it.volume }, bias, closes.takeLast(60), candles.takeLast(60), sweep, structure,
        refHigh, refLow, ema20, ema50, atr14, volumeRatio, score)
}
private fun fmt(v: Double) = String.format(Locale.US, "%,.2f", v)
private enum class Signal { BUY, SELL, WAIT }
private fun signalFor(frames: List<FrameData>): Signal {
    if (frames.size < 3) return Signal.WAIT
    val score = frames.map { it.technicalScore }.average()
    val up = frames.count { it.technicalScore >= 20 }; val down = frames.count { it.technicalScore <= -20 }
    return when { score >= 25 && up >= 2 -> Signal.BUY; score <= -25 && down >= 2 -> Signal.SELL; else -> Signal.WAIT }
}
private fun t(lang: String, key: String): String {
    val ar = mapOf("subtitle" to "تحليل ذكي لأماكن السيولة", "market" to "السوق", "timeframe" to "الإطار الزمني", "refresh" to "تحديث الآن", "buy" to "إشارة شراء", "sell" to "إشارة بيع", "wait" to "انتظار", "entry" to "سعر الدخول", "targets" to "الأهداف المقترحة", "stop" to "وقف الخسارة", "trend" to "اتجاه السوق", "liquidity" to "السيولة", "summary" to "ملخص التحليل", "auto" to "تحديث تلقائي كل 60 ثانية", "updated" to "آخر تحديث", "loading" to "جارٍ جلب بيانات السوق...", "error" to "تعذر جلب البيانات", "home" to "الرئيسية", "markets" to "الأسواق", "alerts" to "التنبيهات", "settings" to "الإعدادات", "neutral" to "محايد")
    val fr = mapOf("subtitle" to "Analyse intelligente de la liquidité", "market" to "Marché", "timeframe" to "Intervalle", "refresh" to "Actualiser", "buy" to "Signal ACHAT", "sell" to "Signal VENTE", "wait" to "ATTENTE", "entry" to "Prix d’entrée", "targets" to "Objectifs", "stop" to "Stop Loss", "trend" to "Tendance", "liquidity" to "Liquidité", "summary" to "Résumé de l’analyse", "auto" to "Actualisation auto. toutes les 60 s", "updated" to "Dernière mise à jour", "loading" to "Chargement des données...", "error" to "Données indisponibles", "home" to "Accueil", "markets" to "Marchés", "alerts" to "Alertes", "settings" to "Paramètres", "neutral" to "Neutre")
    val en = mapOf("subtitle" to "AI liquidity market analysis", "market" to "Market", "timeframe" to "Timeframe", "refresh" to "Refresh now", "buy" to "BUY SIGNAL", "sell" to "SELL SIGNAL", "wait" to "WAIT", "entry" to "Entry price", "targets" to "Profit targets", "stop" to "Stop loss", "trend" to "Market trend", "liquidity" to "Liquidity", "summary" to "Analysis summary", "auto" to "Auto refresh every 60 seconds", "updated" to "Last update", "loading" to "Loading market data...", "error" to "Unable to load data", "home" to "Home", "markets" to "Markets", "alerts" to "Alerts", "settings" to "Settings", "neutral" to "Neutral")
    return when (lang) { "fr" -> fr[key] ?: key; "en" -> en[key] ?: key; else -> ar[key] ?: key }
}

@Composable
private fun LiquidityDashboard() {
    val symbols = listOf("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT", "ADAUSDT", "DOGEUSDT")
    var selected by remember { mutableStateOf("BTCUSDT") }; var language by remember { mutableStateOf("ar") }
    var state by remember { mutableStateOf(MarketState()) }; var auto by remember { mutableStateOf(true) }
    val handler = remember { Handler(Looper.getMainLooper()) }
    fun refresh(symbol: String) { state = state.copy(symbol = symbol, loading = true, error = null); loadSymbol(symbol) { result -> handler.post { state = result } } }
    DisposableEffect(selected, auto) {
        val task = object : Runnable { override fun run() { refresh(selected); if (auto) handler.postDelayed(this, 60_000L) } }
        handler.removeCallbacksAndMessages(null); task.run(); onDispose { handler.removeCallbacks(task) }
    }
    val signal = signalFor(state.frames); val frame = state.frames.firstOrNull { it.interval == "1h" }
    val price = state.price ?: frame?.last ?: 0.0; val atrValue = frame?.atr14 ?: 0.0
    val entry = price; val direction = if (signal == Signal.SELL) -1.0 else 1.0
    val tp1 = entry + direction * atrValue * 1.0; val tp2 = entry + direction * atrValue * 1.8; val tp3 = entry + direction * atrValue * 2.6
    val sl = entry - direction * atrValue * 1.2
    val signalColor = when(signal) { Signal.BUY -> GREEN; Signal.SELL -> RED; Signal.WAIT -> GOLD }
    val rtl = language == "ar"
    CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Scaffold(containerColor = BG) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("AI Liquidity Signal", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold); Text(t(language, "subtitle"), color = MUTED, fontSize = 12.sp) }
                    Surface(color = Color(0xFF07351F), shape = RoundedCornerShape(20.dp)) { Text("v0.5", color = GREEN, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontWeight = FontWeight.Bold) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("ar" to "🇩🇿 العربية", "fr" to "🇫🇷 Français", "en" to "🇬🇧 English").forEach { (code, label) ->
                        FilterChip(selected = language == code, onClick = { language = code }, label = { Text(label, fontSize = 11.sp) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    var expanded by remember { mutableStateOf(false) }
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("${t(language,"market")}: ${selected.removeSuffix("USDT")}") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { symbols.forEach { sym -> DropdownMenuItem(text = { Text(sym.removeSuffix("USDT")) }, onClick = { selected = sym; expanded = false }) } }
                    }
                    Button(onClick = { refresh(selected) }) { Text("↻") }
                }
                Card(colors = CardDefaults.cardColors(containerColor = PANEL), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(selected, color = MUTED, fontWeight = FontWeight.Bold); Text("${state.change24h?.let { String.format(Locale.US, "%+.2f%%", it) } ?: "—"}", color = if ((state.change24h ?: 0.0) >= 0) GREEN else RED) }
                        Text(state.price?.let { fmt(it) } ?: if (state.loading) t(language,"loading") else "—", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        CandleChart(frame?.candles ?: emptyList(), signal, Modifier.fillMaxWidth().height(230.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("15m · 1h · 5m", color = MUTED, fontSize = 11.sp); Text("${t(language,"updated")}: ${state.updatedAt}", color = MUTED, fontSize = 11.sp) }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = PANEL2), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(when(signal) { Signal.BUY -> t(language,"buy"); Signal.SELL -> t(language,"sell"); Signal.WAIT -> t(language,"wait") }, color = signalColor, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text(when(signal) { Signal.BUY -> "▲ BUY"; Signal.SELL -> "▼ SELL"; Signal.WAIT -> "— WAIT" }, color = signalColor, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("${t(language,"entry")}: ${if (price > 0) fmt(entry) else "—"} USDT", color = Color.White, fontSize = 17.sp)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard(t(language,"trend"), frame?.bias?.let { if (it == "Bullish") "↗ Bullish" else if (it == "Bearish") "↘ Bearish" else t(language,"neutral") } ?: "—", BLUE, Modifier.weight(1f))
                    MetricCard("RSI (14)", frame?.let { String.format(Locale.US,"%.1f",it.rsi) } ?: "—", if ((frame?.rsi ?: 50.0) > 70) RED else GREEN, Modifier.weight(1f))
                }
                Card(colors = CardDefaults.cardColors(containerColor = PANEL), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(t(language,"targets"), color = GREEN, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        val levelsReady = price > 0 && signal != Signal.WAIT && atrValue > 0
                        LevelRow("TP1", if (levelsReady) fmt(tp1) else "—", GREEN); LevelRow("TP2", if (levelsReady) fmt(tp2) else "—", GREEN); LevelRow("TP3", if (levelsReady) fmt(tp3) else "—", GREEN)
                        Divider(color = RED.copy(alpha=.5f)); LevelRow("SL · ${t(language,"stop")}", if (levelsReady) fmt(sl) else "—", RED)
                        Text("${t(language,"liquidity")}: ${frame?.sweep ?: "—"}", color = MUTED, fontSize = 12.sp)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(t(language,"auto"), color = Color.White, fontSize = 12.sp); Switch(auto, { auto = it }) }
                state.error?.let { Text("${t(language,"error")}: $it", color = RED, fontSize = 12.sp) }
                Card(colors = CardDefaults.cardColors(containerColor = PANEL), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(t(language,"summary"), color = BLUE, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("EMA20 / EMA50: ${frame?.let { "${fmt(it.ema20)} / ${fmt(it.ema50)}" } ?: "—"}", color = Color.White, fontSize = 12.sp)
                        Text("${frame?.structure ?: "—"}", color = MUTED, fontSize = 12.sp)
                        Text("Signal rule: multi-timeframe score confirmation; no confirmed setup = WAIT.", color = GOLD, fontSize = 11.sp)
                    }
                }
                Text("Binance public market data · Educational analysis only. No trades are executed.", color = MUTED, fontSize = 10.sp)
            }
        }
    }
}

@Composable private fun MetricCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = PANEL), shape = RoundedCornerShape(15.dp)) { Column(Modifier.fillMaxWidth().padding(12.dp)) { Text(title, color = MUTED, fontSize = 12.sp); Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold) } }
}
@Composable private fun LevelRow(label: String, value: String, color: Color) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = color, fontWeight = FontWeight.Bold); Text("$value USDT", color = Color.White, fontWeight = FontWeight.SemiBold) } }

@Composable private fun CandleChart(candles: List<Candle>, signal: Signal, modifier: Modifier = Modifier) {
    Canvas(modifier.background(Color(0xFF071321), RoundedCornerShape(12.dp)).padding(8.dp)) {
        if (candles.size < 3) return@Canvas
        val data = candles.takeLast(48); val minV = data.minOf { it.low }; val maxV = data.maxOf { it.high }; val range = (maxV - minV).takeIf { it > 0 } ?: 1.0
        fun y(v: Double) = size.height - ((v - minV) / range * size.height).toFloat()
        for (i in 1..3) { val yy = size.height * i / 4f; drawLine(Color(0xFF20344B), Offset(0f, yy), Offset(size.width, yy), 1f) }
        val step = size.width / data.size; val bodyW = step * .55f
        data.forEachIndexed { i, c ->
            val x = step * i + step / 2f; val color = if (c.close >= c.open) GREEN else RED
            drawLine(color, Offset(x, y(c.high)), Offset(x, y(c.low)), 2f)
            val top = minOf(y(c.open), y(c.close)); val bottom = maxOf(y(c.open), y(c.close)).coerceAtLeast(top + 2f)
            drawRect(color, Offset(x - bodyW/2, top), androidx.compose.ui.geometry.Size(bodyW, bottom-top))
            // Mark the latest completed candle with the current confirmed signal.
            if (i == data.lastIndex && signal != Signal.WAIT) {
                val markerY = if (signal == Signal.BUY) y(c.low) + 17f else y(c.high) - 17f
                val path = Path().apply { if (signal == Signal.BUY) { moveTo(x, markerY-12); lineTo(x-9, markerY+4); lineTo(x+9, markerY+4) } else { moveTo(x, markerY+12); lineTo(x-9, markerY-4); lineTo(x+9, markerY-4) }; close() }
                drawPath(path, if (signal == Signal.BUY) GREEN else RED)
            }
        }
    }
}
